public class Omakotitalo extends Rakennus {

    public Omakotitalo(int asuntojen_lkm, Asunto asunto, String tyyppi) {
        super(asuntojen_lkm, asunto, tyyppi);
    }     
}
