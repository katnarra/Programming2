public class Kerrostalo extends Rakennus{        

    public Kerrostalo(int asuntojen_lkm, Asunto asunto, String tyyppi) {
        super(asuntojen_lkm, asunto, tyyppi);
    }
}
