public class Rivitalo extends Rakennus {
    public Rivitalo(int asuntojen_lkm, Asunto asunto, String tyyppi) {
        super(asuntojen_lkm, asunto, tyyppi);
    }  
}
